<html><head>
    <meta charset="utf-8">
    <title>BEACH-INVEST – это совершенно новый подход к деловым отношениям и пассивному заработку!</title> 
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=9">
    <link rel="stylesheet" href="/css/style.css">
    <script type="text/javascript" src="/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="/js/jquery.tools.min.js"></script>
    <script type="text/javascript" src="/js/scripts.js"></script>
	<script type="text/javascript" src="/js/script.js"></script>
	<script type="text/javascript" src="/js/js.js"></script>
	<!-- <link rel="stylesheet" type="text/css" href="/css/settings.css">
	<link rel="stylesheet" type="text/css" href="/css/editor.css"> -->
    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body class="splash">
    <div class="site">
        <div class="wrap">
            <header>
                <div class="header">
                    <div class="header_top cfix">
                        <a href="/" class="logo">BEACH-INVEST</a>
                        <div class="header_top_right">
                            <div class="htr_bottom cfix">
                            		                                <a href="/login" class="input">Войти</a>&nbsp;
	                                <a href="/register" class="input">Регистрация</a>&nbsp;
								                                <a style="background: #10A3B4;" href="https://vk.com/club52436411" target="_blank" class="input">Мы ВКонтакте</a>
                            </div>
                        </div>
                    </div>
                    <nav class="menuTop cfix">
                        <a href="/" class="active">Главная</a>
                        <span></span>
                        <a href="/news" class="">Новости</a>
                        <span></span>
                        <a href="/about" class="">О нас</a>
                        <span></span>
                        <a href="/otziv" class="">Отзывы</a>
                        <span></span>
                        <a href="/market" class="">Маркетинг</a>
                        <span></span>
                        <a href="/rules" class="">FAQ</a>
                        <span></span>
                        <a href="/contacts" class="">Контакты</a>
                    </nav>
                </div>
            </header>
            <section class="scontent">

            <center>
            <h1 class="otz"><span class="poloska">404 ошибка</span></h1>
            <br>
            <b style="font-size:1.7em;">Указанная страница отсутствует на сервере</b>
            </center>

            </section>
        </div>
    </div>
    <footer>
        <div class="footer_payments">
            <a href="#"></a>
            <a href="#"><img src="" alt=""></a>
            <a href="#"><img src="" alt=""></a>
            <a href="#"><img src="" alt=""></a>
        </div>
        <div class="footer_menu">
            <nav class="menuTop cfix">
                <a href="/" class="active">Главная</a>
                <span></span>
                <a href="/news" class="">Новости</a>
                <span></span>
                <a href="/about" class="">О нас</a>
                <span></span>
                <a href="/otziv" class="">Отзывы</a>
                <span></span>
                <a href="/market" class="">Маркетинг</a>
                <span></span>
                <a href="/rules" class="">FAQ</a>
                <span></span>
                <a href="/success" class="">Соглашение</a>
            </nav>
        </div>
        <div class="footer_bottom cfix">
            <div class="footer_bottom_copyright">BEACH-INVEST©2015</div>
            <div class="footer_bottom_ssl">
                <a href="https://ddos-guard.net" target="_blank"><img src="/img/ddos_guard.png" alt="" height="55"></a>
                <a href="http://www.comodo.com/" target="_blank"><img src="/img/cs.png" alt="" height="55"></a>
                <a href="http://www.positivessl.biz/" target="_blank"><img src="/img/ssl.png" alt="" height="55"></a>
            </div>
        </div>
    </footer>


</body></html>