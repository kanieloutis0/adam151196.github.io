﻿       </section>
        </div>
    </div>
    <footer>
        <div class="footer_payments">
            <a href="#"></a>
            <a href="#"><img src="" alt=""></a>
            <a href="#"><img src="" alt=""></a>
            <a href="#"><img src="" alt=""></a>
        </div>
        <div class="footer_menu">
            <nav class="menuTop cfix">
                <a href="/" class="active">Главная</a>
                <span></span>
                <a href="/news" class="">Новости</a>
                <span></span>
                <a href="/about" class="">О нас</a>
                <span></span>
                <a href="/otziv" class="">Отзывы</a>
                <span></span>
                <a href="/market" class="">Маркетинг</a>
                <span></span>
                <a href="/rules" class="">FAQ</a>
                <span></span>
                <a href="/success" class="">Соглашение</a>
            </nav>
        </div>
        <div class="footer_bottom cfix">
            <div class="footer_bottom_copyright">BEACH-INVEST©2015</div>
            <div class="footer_bottom_ssl">
                <a href="https://ddos-guard.net" target="_blank"><img src="/img/ddos_guard.png" alt="" height="55"></a>
                <a href="http://www.comodo.com/" target="_blank"><img src="/img/cs.png" alt="" height="55"></a>
                <a href="http://www.positivessl.biz/" target="_blank"><img src="/img/ssl.png" alt="" height="55"></a>
            </div>
        </div>
    </footer>
</body>
</html>