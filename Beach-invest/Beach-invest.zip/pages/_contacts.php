﻿<h1 class="otz" style="text-align:center;"><span class="poloska">БОЛЬШОЙ РОЗЫГРЫШ</span></h1>
<section class="scontent">
<div>Загрузка таймера</div>
<br><br>
В течении месяца все участники, сделавшие вклад на сумму от 10 рублей участвуют в Большом Розыгрыше нашего проекта.
29-го Мая в 14:00 по МСК мы определим трех победителей в онлайн-трансляции. Трансляцию мы проведем в нашей группе вконтакте (http://vk.com/monies24). 
<br><br>
1 место: 200.000 рублей<br>
2 место: 100.000 рублей <br>
3 место: 50.000 рублей<br>
4 место: 5.000 рублей<br>
<br><br>
Обратите внимание, выплаты в Розыгрыше осуществляются на банковские карты VISA и MasterCard, прямые банковские счета, 
либо платежные системы QIWI
<br><br>
monies24.com
<br>
</section>


<!--Начало кода "proТаймера" (id:7334)--><script type="text/javascript" src="http://files.makedreamprofits.ru/js/jmdp.js"></script><script type="text/javascript">(function(d,w){n=d.getElementsByTagName("script")[0],s=d.createElement("script"),f=function(){n.parentNode.insertBefore(s,n);};s.type="text/javascript";s.async=true;o=(new Date()).getTimezoneOffset();qs=document.location.search.split("+").join(" ");re=/[?&]?([^=]+)=([^&]*)/g;m="";while(tokens=re.exec(qs))if("email"===decodeURIComponent(tokens[1])) m=decodeURIComponent(tokens[2]);i="553a400a91d28";s.src="http://cdcs.makedreamprofits.ru/?"+i+"&"+o+"&"+m; if("[object Opera]"===w.opera)d.addEventListener("DomContentLoaded",f,false);else f();})(document, window);</script><!--Конец кода "proТаймера"-->