﻿<?PHP

$_OPTIMIZATION["title"] = "Ошибка";
$_OPTIMIZATION["description"] = "Указанная страница отсутствует на сервере";
$_OPTIMIZATION["keywords"] = "Ошибка, error, 404, Not Found";
?>

 <center>
<h1 class="otz"><span class="poloska">404 ошибка</span></h1>
<br>
<b style="font-size:1.7em;">Указанная страница отсутствует на сервере</b>
</center>
